﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_PAP
{
    internal class NavigationsParameters
    {
        internal PasswordEncrypt Encryptor { get; set; }
        internal string UserEmail { get; set; }
        public string TotpSecret { get; set; }
        public bool RequireVerificationForActions { get; set; }
    }
}
